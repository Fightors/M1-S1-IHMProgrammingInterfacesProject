document.addEventListener("DOMContentLoaded", () => {
    Controller.init();
});
